# Voyage AI Dev Framework v4.0

> AI-Native Engineering Operating System for solo developers and small teams.

## 🚀 Quick Start

1. Read [VOYAGE_FRAMEWORK_MASTER_DOCUMENT.md](./VOYAGE_FRAMEWORK_MASTER_DOCUMENT.md) for full architecture.
2. Check [RULES.md](./RULES.md) for executable rules.
3. Pick a role from [docs/roles/](./docs/roles/) for your current task.
4. Follow [docs/strategy/TEST_STRATEGY.md](./docs/strategy/TEST_STRATEGY.md) for quality gates.

## 📁 Repository Structure

```
voyage-framework/
├── README.md
├── VOYAGE_FRAMEWORK_MASTER_DOCUMENT.md
├── RULES.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── docs/
│   ├── adr/              # Architecture Decision Records
│   ├── roles/            # AI role definitions
│   ├── strategy/         # Plans, testing, status
│   ├── analysis/         # External integration analyses
│   └── infrastructure/   # Infrastructure decisions
├── prompts/              # Ready-to-use prompts for Kimi Code / ChatGPT
├── archive/              # Deprecated versions for history
└── .github/workflows/    # CI automation
```

## 📋 Architecture Decisions (ADR)

| # | Title | Status |
|---|-------|--------|
| [ADR-001](./docs/adr/ADR-001-postgresql-events.md) | PostgreSQL Events | ✅ Accepted |
| [ADR-002](./docs/adr/ADR-002-chromadb-semantic.md) | ChromaDB Semantic | ✅ Accepted |
| [ADR-003](./docs/adr/ADR-003-tree-sitter-ast.md) | Tree-sitter AST | ✅ Accepted |
| [ADR-004](./docs/adr/ADR-004-dual-location.md) | Dual Location | ✅ Accepted |
| [ADR-005](./docs/adr/ADR-005-project-isolation.md) | Project Isolation | ✅ Accepted |
| [ADR-006](./docs/adr/ADR-006-rule-governance.md) | Rule Governance | ✅ Accepted |
| [ADR-007](./docs/adr/ADR-007-runtime-orchestration.md) | Runtime Orchestration | ✅ Accepted |
| [ADR-008](./docs/adr/ADR-008-observability.md) | Observability | ✅ Accepted |
| [ADR-009](./docs/adr/ADR-009-complexity-budget.md) | Complexity Budget | ✅ Accepted |

See full index: [ADR-INDEX.md](./docs/adr/ADR-INDEX.md)

## 🎭 Roles

| ID | Role | Status |
|----|------|--------|
| [ROLE-000](./docs/roles/ROLE-000-base-role.md) | Base Role (template) | ✅ Active |
| [ROLE-001](./docs/roles/ROLE-001-qa-engineer.md) | QA Engineer | ✅ Active |
| [ROLE-002](./docs/roles/ROLE-002-security-engineer.md) | Security Engineer | ✅ Active |
| [ROLE-003](./docs/roles/ROLE-003-reviewer-engineer.md) | Reviewer Engineer | ✅ Active |

See full index: [ROLE-INDEX.md](./docs/roles/ROLE-INDEX.md)

## 🧪 Testing

- [TEST_STRATEGY.md](./docs/strategy/TEST_STRATEGY.md) — Complete testing strategy
- [PHASE2_PLAN.md](./docs/strategy/PHASE2_PLAN.md) — Phase 2 execution plan
- [PHASE_STATUS.md](./docs/strategy/PHASE_STATUS.md) — Current phase status

## 🔗 External Analyses

- [LangGraph Integration Analysis](./docs/analysis/LANGGRAPH_INTEGRATION_ANALYSIS.md)

## 🛡️ Security

- [TECH-001: AppSec Stack](./docs/infrastructure/TECH-001-appsec-stack.md)

## 📜 Changelog

See [CHANGELOG.md](./CHANGELOG.md)

## 🤝 Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md)

---
*Repository: https://github.com/AndreyVoyage/Framework-voyage-v2*  
*Version: v4.0*  
*Last updated: 2026-05-28*
